#pragma once
class student
{
};

