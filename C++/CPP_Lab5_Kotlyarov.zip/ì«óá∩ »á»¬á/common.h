#pragma once
class common
{
};

