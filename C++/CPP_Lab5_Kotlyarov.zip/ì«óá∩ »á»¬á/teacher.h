#pragma once
class teacher
{
};

