﻿#include <iostream>
#include "student.h"
#include "teacher.h"
#include "common.h"

int main()
{
    std::cout << "Hello World!\n";
}


