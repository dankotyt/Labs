﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp__4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice = 0;
            bool quit = true;
            Console.WriteLine("\nГлубокое копирование с сериализацией: ");
            Console.WriteLine();
            Person person = new Person("Name", "Surname", new DateTime(2004, 12, 12));
            Student student = new Student(person, Education.Bachelor, 126);
            Exam[] exams = new Exam[3];
            exams[0] = new Exam("Russian", 4, new DateTime(2022, 10, 1));
            exams[1] = new Exam("IT", 5, new DateTime(2023, 11, 5));
            exams[2] = new Exam("Math", 5, new DateTime(2023, 10, 15));
            student.AddExams(exams);
            Student student1 = student.DeepCopySerialization();
            Console.WriteLine(student.ToString());
            Console.WriteLine(student1.ToString());
            Console.WriteLine();

            string fn;
            Student student2 = new Student(person, Education.Bachelor, 126);
            Console.WriteLine("\nВведите название файла: ");
            fn = Console.ReadLine() + ".bin";
            Console.WriteLine();
            if (File.Exists(fn))
            {
                if (student2.Load(fn))
                {
                    Console.WriteLine("\nДанные загружены!");
                }
                else
                {
                    Console.WriteLine("\nОшибка загрузки данных!");
                }
            }
            else
            {
                Console.WriteLine("\nДанного файла не существует! Создаю файл автоматически.");
                File.Create(fn).Close();
            }
            Console.WriteLine("\nВывод информации через метод ToString.");
            Console.WriteLine(student2.ToString());
            Console.WriteLine();

            Console.WriteLine("\nВвод данных.");
            student2.AddFromConsole();
            Console.WriteLine();
            Console.WriteLine("\nСохранение данных...");
            student2.Save(fn);
            Console.WriteLine("Данные сохранены");
            Console.WriteLine();
            Console.WriteLine("\nВывод информации через метод ToString.");
            Console.WriteLine(student2.ToString());
            Console.WriteLine("\nЗагрузка данных из файла...");
            Student.Load(fn, ref student2);
            Console.WriteLine("Данные загружены");
            Console.WriteLine();
            Console.WriteLine("\nВвод данных для обновления.");
            student2.AddFromConsole();
            Console.WriteLine();
            Console.WriteLine("\nСохранение данных...");
            Student.Save(fn, ref student2);
            Console.WriteLine("Данные сохранены");
            Console.WriteLine();
            Console.WriteLine("\nВывод обновлённой информации через метод ToString.");
            Console.WriteLine(student2.ToString());

            Console.WriteLine("\nДобавим ещё? 1 - да, 2 - нет: ");
            choice = Convert.ToInt32(Console.ReadLine());
            while (quit)
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("\nВвод данных.");
                        student2.AddFromConsole();
                        Console.WriteLine();
                        Console.WriteLine("\nСохранение данных...");
                        student2.Save(fn);
                        Console.WriteLine("Данные сохранены");
                        Console.WriteLine();
                        Console.WriteLine("\nВывод информации через метод ToString.");
                        Console.WriteLine(student2.ToString());
                        Console.WriteLine("\nЗагрузка данных из файла...");
                        Student.Load(fn, ref student2);
                        Console.WriteLine();
                        Console.WriteLine("Данные загружены");
                        Console.WriteLine("\nВвод данных для обновления.");
                        student2.AddFromConsole();
                        Console.WriteLine();
                        Console.WriteLine("\nСохранение данных...");
                        Student.Save(fn, ref student2);
                        Console.WriteLine("Данные сохранены");
                        Console.WriteLine();
                        Console.WriteLine("\nВывод обновлённой информации через метод ToString.");
                        Console.WriteLine(student2.ToString());
                        choice = 0;
                        break;
                    case 2:
                        //Console.WriteLine("\nНажмите любую кнопку для закрытия программы.");
                        break;
                }
                quit = false;
            }
            //student2.AddFromConsole();
            //Console.WriteLine();
            //Student.Save(fn, ref student2);
            //Console.WriteLine("Данные сохранены");
            //Console.WriteLine();
            //Console.WriteLine(student2.ToString());
            Console.WriteLine("\nНажмите любую кнопку для закрытия программы.");
            Console.Read();
        }
    }
}
