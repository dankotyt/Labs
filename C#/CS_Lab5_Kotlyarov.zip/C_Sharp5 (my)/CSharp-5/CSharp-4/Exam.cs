﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp__4
{
    [Serializable]
    internal class Exam : IDateAndCopy, IComparable, IComparer<Exam>
    {
        #region Propetries
        public string SubjectName { get; set; }
        public int Mark { get; set; }
        public DateTime Date { get; set; }
        #endregion

        #region Constructors
        public Exam(string subjectName, int mark, DateTime date)
        {
            SubjectName = subjectName;
            this.Mark = mark;
            this.Date = date;
        }
        public Exam()
        {
            SubjectName = "";
            Mark = 0;
            Date = DateTime.MinValue;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return SubjectName + " " + Mark.ToString() + " " + Date.ToShortDateString();
        }
        

        public object DeepCopy()
        {
            return new Exam(SubjectName, Mark, Date);
        }

        public int CompareTo(object exam)
        {
            return SubjectName.CompareTo((exam as Exam).SubjectName);
        }


        public int Compare(Exam exam1, Exam exam2)
        {
            return exam1.Mark - exam2.Mark;

        }

        public class DateCompare : IComparer<Exam>
        {
            public int Compare(Exam exam1, Exam exam2)
            {
                return exam1.Date.CompareTo(exam2.Date);
            }

        }
        #endregion


    }
}
