﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;




namespace CSharp__4
{
    delegate void StudentsChangedHandler<TKey>(object source, StudentsChangedEventArgs<TKey> args);
    delegate TKey KeySelector<TKey>(Student st);
    
    internal class StudentCollection<TKey>
    {
        #region Field And Propertied And Events
        private Dictionary<TKey, Student> _dict;
        private KeySelector<TKey> _keySelector;
        public string NameCollection { get; set; }
        public  event StudentsChangedHandler<TKey> StudentChanged;
        #endregion

        #region Constructor
        public StudentCollection(KeySelector<TKey> keySelector)
        {
            _dict = new Dictionary<TKey, Student>();
            _keySelector = keySelector;
        }
        #endregion

        #region Methods
        public bool Remove(Student st)
        {
            foreach(var item in _dict)
            {
                if (item.Value.Equals(st))
                {
                    OnStudentChanged("StudentCollection", Action.Remove, this.GetType().Name, item.Key);
                    item.Value.PropertyChanged -= HandleEvent;
                    return _dict.Remove(item.Key);
                }
            }
            return false;
        }

        public void OnStudentChanged(string prop, Action action, string source, TKey key )
        {
            if (StudentChanged != null)
                StudentChanged(this, new StudentsChangedEventArgs<TKey>(prop,action,source,key));

        }
       
        public static string DefineKey(Student val)
        {
            return val.GroupNumber.ToString();
        }
        public void AddDefaults()
        {
            Student student = new Student(new Person("Name", "Surname", new DateTime(2004, 12, 12)), Education.Specialist, 126);
            OnStudentChanged("StudentCollection", Action.Add, this.GetType().Name, _keySelector(student));
            _dict.Add(_keySelector(student), student);
        }

        public void AddStudents(params Student[] students)
        {
            for (int i = 0; i < students.Length; i++)
            {
                _dict.Add(_keySelector(students[i]), students[i]);
                OnStudentChanged("StudentCollection", Action.Add, this.GetType().Name, _keySelector(students[i]));
                students[i].PropertyChanged += HandleEvent;
            }
        }

        private void HandleEvent(object subject, EventArgs e)
        {
            var it = (PropertyChangedEventArgs)e;
            var mg = (Student)subject;
            var key = _keySelector(mg);
            OnStudentChanged("StudentCollection",Action.Property, it.PropertyName, key);
        }

        public override string ToString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString() + " ");
                OnStudentChanged("StudentCollection", Action.Property, this.GetType().Name, entry.Key);
                line.Append(entry.Value.ToString());
                line.Append("\n");
            }
            return line.ToString();
        }

        public string ToShortString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString());
                line.Append(entry.Value.ToShortString());
            }
            return line.ToString();
        }

        public double MaxAverageMark
        {
            get
            {
                List<double> averageMarks = new List<double>();
                foreach (var i in _dict)
                {
                    averageMarks.Add(i.Value.MiddleMark);
                }
                return Enumerable.Max(averageMarks);
            }
        }


        public IEnumerable<KeyValuePair<TKey, Student>> EducationForm(Education value)
        {

            IEnumerable<KeyValuePair<TKey, Student>> educDict = _dict.Where(x => x.Value.Education.Equals(value));
            return educDict;
        }

        public IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> groupDict
        {
            get
            {
                IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> group = _dict.GroupBy(x => x.Value.Education);
                return group;

            }
        }
        #endregion

    }
}
