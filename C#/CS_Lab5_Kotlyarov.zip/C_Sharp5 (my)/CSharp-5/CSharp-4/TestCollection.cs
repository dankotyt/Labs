﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

delegate System.Collections.Generic.KeyValuePair<TKey, TValue> GenerateElement<TKey, TValue>(int j);

namespace CSharp__4
{

    internal class TestCollections<TKey, TValue>
    {
        /*
         универсальный класс TestCollections<TKey,TValue>, который содержит
         закрытые поля следующих типов
          • System.Collections.Generic.List<TKey>;
          • System.Collections.Generic.List<string> ;
          • System.Collections.Generic.Dictionary<TKey, TValue> ;
          • System.Collections.Generic.Dictionary<string, TValue>;
          • GenerateElement<TKey, TValue>. 
         */
        private System.Collections.Generic.List<TKey> _list;
        private System.Collections.Generic.List<string> _list2;
        private System.Collections.Generic.Dictionary<TKey, TValue> _dict;
        private System.Collections.Generic.Dictionary<string, TValue> _dict2;
        private GenerateElement<TKey, TValue> generateElement;


        //Зона конструкторов
        /*
           В конструкторе класса TestCollections<TKey,TValue> создаются
           коллекции с заданным числом элементов. Надо сравнить время поиска
           элемента в коллекциях-списках List<TKey> и время поиска элемента по ключу
           и элемента по значению в коллекциях-словарях Dictionary<TKey,TValue>. 
         */

        public TestCollections(int size, GenerateElement<TKey, TValue> j)
        {
            _list = new List<TKey>();
            _list2 = new List<string>();
            _dict = new Dictionary<TKey, TValue>();
            _dict2 = new Dictionary<string, TValue>();
            generateElement = j;
            for (int i = 0; i < size; i++)
            {
                var elem = generateElement(i);
                _dict.Add(elem.Key, elem.Value);
                _dict2.Add(elem.Key.ToString(), elem.Value);
                _list.Add(elem.Key);
                _list2.Add(elem.Key.ToString());
            }
        }

        /*
         В конструкторе класса TestCollections<TKey,TValue> создаются
         коллекции с заданным числом элементов. Надо сравнить время поиска
         элемента в коллекциях-списках List<TKey> и время поиска элемента по ключу
         и элемента по значению в коллекциях-словарях Dictionary<TKey,TValue>. 
         */
        public static KeyValuePair<Person, Student> GenerateElement(int j)
        {
            Person key = new Person("Name" + j, "Surname" + j, new DateTime(2000 + j % 30, 1 + j % 12, 1 + j % 30));
            Exam exam = new Exam(j.ToString(), j % 5, new DateTime(2000 + j % 30, 1 + j % 12, 1 + j % 30));
            Test test;
            if (j % 2 == 0)
            {
                test = new Test(j.ToString(), true);
            }
            else
            {
                test = new Test(j.ToString(), false);
            }
            List<Exam> L_E = new List<Exam>(); L_E.Add(exam);
            List<Test> L_T = new List<Test>(); L_T.Add(test);
            Student value = new Student(key, Education.Bachelor, 100 + j);
            return new KeyValuePair<Person, Student>(key, value);
        }


        /*
         * Для четырех разных элементов - первого, центрального, последнего и
        элемента, не входящего в коллекцию, - надо измерить время поиска
            • элемента в коллекциях List<TKey> и List<string> с помощью метода
            Contains;
            • элемента по ключу в коллекциях Dictionary< TKey, TValue> и Dictionary
            <string, TValue > с помощью метода ContainsKey;
            • значения элемента в коллекции Dictionary< TKey, TValue > с помощью
            метода ContainsValue.
        Так как статический метод для автоматической генерации элементов
        должен обеспечивать взаимно-однозначное соответствие между значением
        целочисленного параметра метода и объектами TKey, его можно
        использовать как при создании коллекций, так и для генерации элемента для
        поиска.   */
        public void searchListOfTKeys()
        {
            TKey firstElement = _list.First();
            TKey middleElement = _list.ToArray()[_list.Count / 2];
            TKey lastElement = _list.ToArray()[_list.Count - 1];
            TKey noneElement = generateElement(_list.Count + 1).Key;

            Console.WriteLine($"\nВремя list of TKeys");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _list.Contains(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _list.Contains(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _list.Contains(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _list.Contains(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }
        public void searchListOfString()
        {
            string firstElement = _list2.First();
            string middleElement = _list2.ToArray()[_list2.Count / 2];
            string lastElement = _list2.ToArray()[_list2.Count - 1];
            string noneElement = generateElement(_list.Count + 1).Key.ToString();

            Console.WriteLine($"\nВремя list of string");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _list2.Contains(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _list2.Contains(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _list2.Contains(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _list2.Contains(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }
        public void searchKeyInDictOfTKeys()
        {
            TKey firstElement = _dict.ElementAt(0).Key;
            TKey middleElement = _dict.ElementAt(_dict.Count / 2).Key;
            TKey lastElement = _dict.ElementAt(_dict.Count - 1).Key;
            TKey noneElement = generateElement(_list.Count + 1).Key;

            Console.WriteLine($"\nВоемя поиска ключей dictionary of TKeys");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _dict.ContainsKey(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _dict.ContainsKey(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict.ContainsKey(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict.ContainsKey(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }
        public void searchKeyInDictOfString()
        {
            string firstElement = _dict2.ElementAt(0).Key;
            string middleElement = _dict2.ElementAt(_dict2.Count / 2).Key;
            string lastElement = _dict2.ElementAt(_dict2.Count - 1).Key;
            string noneElement = generateElement(_list.Count + 1).Key.ToString();

            Console.WriteLine($"\nВремя поиска ключей в dictionary of String");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _dict2.ContainsKey(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _dict2.ContainsKey(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict2.ContainsKey(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict2.ContainsKey(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }
        public void searchValueInDictOfTKeys()
        {
            TValue firstElement = _dict.ElementAt(0).Value;
            TValue middleElement = _dict.ElementAt(_dict.Count / 2).Value;
            TValue lastElement = _dict.ElementAt(_dict.Count - 1).Value;
            TValue noneElement = generateElement(_list.Count + 1).Value;

            Console.WriteLine($"\nВремя поиска значений в dictionary of TKey");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _dict.ContainsValue(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _dict.ContainsValue(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict.ContainsValue(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict.ContainsValue(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }
        public void searchValueInDictOfString()
        {
            TValue firstElement = _dict2.ElementAt(0).Value;
            TValue middleElement = _dict2.ElementAt(_dict2.Count / 2).Value;
            TValue lastElement = _dict2.ElementAt(_dict2.Count - 1).Value;
            TValue noneElement = generateElement(_list.Count + 1).Value;

            Console.WriteLine($"\nВремя поиска значений в dictionary of String");

            Stopwatch sw = new Stopwatch();
            sw.Start();
            _dict2.ContainsValue(firstElement);
            sw.Stop();
            Console.WriteLine($"Время первого элемента: {sw.Elapsed}");
            sw.Restart();


            sw.Start();
            _dict2.ContainsValue(middleElement);
            sw.Stop();
            Console.WriteLine($"Время центрального элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict2.ContainsValue(lastElement);
            sw.Stop();
            Console.WriteLine($"Время последнего элемента: {sw.Elapsed}");
            sw.Restart();

            sw.Start();
            _dict2.ContainsValue(noneElement);
            Console.WriteLine($"Время элемента не входящего в коллекцию: {sw.Elapsed}");
            sw.Stop();
        }

    }
}
