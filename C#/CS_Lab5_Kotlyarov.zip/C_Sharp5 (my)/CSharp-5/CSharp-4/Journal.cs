﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CSharp__4
{
    internal class Journal
    {
        #region Field
        List<JournalEntry> journalEntries = new List<JournalEntry>();
        #endregion

        #region Methods
        public void OnStudentChanged(object source, EventArgs args)
        {
            var events = args as StudentsChangedEventArgs<string>;
            journalEntries.Add(new JournalEntry(events.NameCollection, events.ActionInfo, events.SourceOfChange, events.Key));

        }
        
        public override string ToString()
        {
            string result = "";
            foreach (var elem in journalEntries)
            {
                result += "\nChange in collection: " + elem.NameCollection + " |Change type: " + elem.ActionInfo + " |Change in property: " + elem.SourceOfChange + " |Element key: " + elem.Key+"\n";
            }
            return result;
        }
        #endregion
    }
}
