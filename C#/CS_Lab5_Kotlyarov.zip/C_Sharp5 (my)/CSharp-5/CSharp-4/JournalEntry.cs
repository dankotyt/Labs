﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp__4
{
    internal class JournalEntry
    {
        #region Properties
        public string NameCollection { get; set; }
        public Action ActionInfo { get; set; }
        public string SourceOfChange { get; set; }
        public string Key { get; set; }
        #endregion

        #region Methods
        public JournalEntry(string nameCollection, Action actionInfo, string sourceOfChange, string key)
        {
            NameCollection = nameCollection;
            ActionInfo = actionInfo;
            SourceOfChange = sourceOfChange;
            Key = key;
        }

        public override string ToString()
        {
            return NameCollection + " " + ActionInfo.ToString() + " " + SourceOfChange + " " + Key.ToString();
        }
        #endregion
    }
}
