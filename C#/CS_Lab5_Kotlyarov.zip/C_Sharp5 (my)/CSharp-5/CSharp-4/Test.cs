﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp__4
{
    [Serializable]
    internal class Test
    {
        #region Properties
        public string title { get; set; }
        public bool isTestPassed { get; set; }
        #endregion

        #region Construction
        public Test(string title, bool isTestPassed)
        {
            this.title = title;
            this.isTestPassed = isTestPassed;
        }

        public Test()
        {
            title = "";
            isTestPassed = false;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return title + " " + isTestPassed.ToString();
        }
        #endregion
    }
}
