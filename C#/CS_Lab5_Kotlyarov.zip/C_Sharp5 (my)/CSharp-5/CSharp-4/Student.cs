﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CSharp__4
{
    [Serializable]
    internal class Student : Person, IDateAndCopy, IEnumerable, INotifyPropertyChanged
    {
        #region Fields
        private Education education;
        private int groupNumber;
        private List<Test> tests;
        private List<Exam> exams;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructions
        // Конструкторы
        public Student(Person person, Education education, int groupNumber) :
            base(person.Name, person.Surname, person.Date)
        {

            this.education = education;
            OnPropertyChanged("Education");
            this.groupNumber = groupNumber;
            OnPropertyChanged("GroupNumber");
            tests = new List<Test>();
            exams = new List<Exam>();
        }

        public Student() :
            base()
        {
            education = new Education();
            groupNumber = 0;
            tests = new List<Test>();
            exams = new List<Exam>();
        }
        #endregion

        #region Properies
        public Education Education
        {
            get
            {
                return education;
            }
            set
            {
                education = value;
                OnPropertyChanged("Education");
            }
        }
        // Свойство получения и изменения person из родительского класса
        public Person person
        {
            get
            {
                return base.DeepCopy() as Person;
            }
            set
            {
                name = base.name;
                surname = base.surname;
                birthday = base.birthday;
            }
        }

        // Свойство экзаменов
        public List<Exam> Exams
        {
            get
            {
                return exams;
            }
            set
            {
                exams = value;
            }
        }

        // Свойство получения и изменения номера группы
        public int GroupNumber
        {
            get { return groupNumber; }
            set
            {

                try
                {
                    if (value <= 100 || value > 599)
                    {
                        throw new Exception("Номер группы должен быть от 101 до 599");
                    }
                    else
                    {
                        groupNumber = value;
                        OnPropertyChanged("GroupNumber");
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
            }
        }
        #endregion

        #region Methods
        public Student DeepCopySerialization()
        {
            byte[] data = new byte[255];
            MemoryStream stream = new MemoryStream();
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, this);
                stream.Position = 0;
                return formatter.Deserialize(stream) as Student;
            }
            catch (Exception e)
            {
                Console.WriteLine("\nОшибка сериализации!", e.Message);
                throw new Exception(e.Message);
            }
            finally { stream.Close(); }
        }

        public bool Save(string fn)
        {
            Stream file = null;
            if (File.Exists(fn))
            {
                try
                {
                    file = File.Open(fn, FileMode.Append);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(file, this);
                    file.Close();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nОшибка сохранения файла!");
                    file.Close();
                    throw new Exception(e.Message);
                    //return false;
                }
                finally { file.Close(); }
            }
            else
            {
                try
                {
                    file = File.Create(fn);
                    file.Close();
                    file = File.Open(fn, FileMode.Append);    
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(file, this);
                    file.Close();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nПроблема с открытием файла!");
                    file?.Close();
                    throw new Exception(e.Message);
                    //return false;
                }
                finally { file?.Close(); }
            }

        }

        public bool Load(string fn)
        {
            Stream file = null;
            if (File.Exists(fn))
            {
                try
                {
                    file = File.OpenRead(fn);
                    BinaryFormatter formatter = new BinaryFormatter();
                    Object a = formatter.Deserialize(file);
                    Student obj = a as Student;
                    file.Close();
                    this.education = obj.education;
                    this.groupNumber = obj.groupNumber;
                    this.tests = new List<Test>(obj.tests);
                    this.exams = new List<Exam>(obj.exams);
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nОшибка загрузки или открытия файла!");
                    file?.Close();
                    throw new Exception(e.Message);
                }
                finally { file?.Close(); }
            }
            else
            {
                Console.WriteLine("\nОшибка загрузки или открытия файла!");
                throw new Exception("\nОшибка!");
                
            }
        }

        public bool AddFromConsole()
        {
            Console.WriteLine("\nВведите название предмета, оценку, год, месяц и день сдачи экзамена: ");
            string[] input = Console.ReadLine().Split(' ');
            Student student = new Student();
            Exam exams = new Exam();
            try
            {
                //student.Name = input[0];
                //student.Surname = input[1];
                exams.SubjectName = input[0];
                if (input[0].Any(c => !char.IsLetter(c))) 
                {
                    throw new Exception();
                }
                exams.Mark = Int32.Parse(input[1]);
            }
            catch (Exception e)
            {
                Console.WriteLine("\nОшибка ввода!");
                throw new Exception(e.Message);
            }
            int y, m, d;
            try
            {
                y = Int32.Parse(input[2]);
                m = Int32.Parse(input[3]);
                d = Int32.Parse(input[4]);
            }
            catch (Exception e)
            {
                Console.WriteLine("\nОшибка ввода!");
                throw new Exception(e.Message);
            }
            exams.Date = new DateTime(y, m, d);
            this.AddExams(exams);
            return true;
        }

        public static bool Save(string fn, ref Student obj)
        {
            Stream file = null;
            if (File.Exists(fn))
            {
                try
                {
                    file = File.Open(fn, FileMode.Append);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(file, obj);
                    file.Close();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nПроблема сохранения файла!");
                    file?.Close();
                    throw new Exception(e.Message);
                }
                finally { file?.Close(); }
            }
            else
            {
                try
                {
                    file = File.Create(fn);
                    file.Close();
                    file = File.Open(fn, FileMode.Append);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(file, obj);
                    file.Close();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nПроблемы сохранения в статической функции!");
                    file?.Close();
                    throw new Exception(e.Message);
                }
                finally
                {
                    file?.Close();
                }
            }
        }

        public static bool Load(string fn, ref Student obj)
        {
            Stream file = null;
            if (File.Exists(fn))
            {
                try
                {
                    file = File.OpenRead(fn);
                    BinaryFormatter formatter = new BinaryFormatter();
                    obj = formatter.Deserialize(file) as Student;
                    file.Close();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nОшибка загрузки файла!");
                    file?.Close();
                    throw new Exception(e.Message);
                }
                finally { file?.Close(); }
            }
            else
            {
                Console.WriteLine("\nФайл не открывается!");
                return false;
            }
        }
        //Создание события
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));

        }
        // Счет средней оценки сданных предметов
        public double MiddleMark
        {
            get
            {
                int count = 0;
                double sum = 0;
                for (int i = 0; i < exams.Count; i++)
                {
                    count++;
                    sum += exams[i].Mark;

                }
                return sum / count;
            }
        }

        //Добавление новых элементов в списки exams и tests
        public void AddExams(params Exam[] exams)
        {
            for (int i = 0; i < exams.Length; i++)
            {
                this.exams.Add(exams[i]);
            }
        }
        public void AddTest(Test test)
        {
            tests.Add(test);
        }

        //Индексатор для Education
        public bool this[Education education]
        {
            get
            {
                return this.education.Equals(education);
            }
        }

        

        // Преобразование в строку
        public override string ToString()
        {
            StringBuilder infoExams = new StringBuilder();
            for (int i = 0; i < exams.Count; i++)
            {
                infoExams.Append(exams[i].ToString() + " ");
            }
            for (int i = 0; i < tests.Count; i++)
            {
                infoExams.Append(tests[i].ToString() + " ");
            }
            return person.ToString() + " " + education.ToString() + " " + groupNumber.ToString() + " " + infoExams;
        }

        public virtual string ToShortString()
        {
            return person.ToString() + " " + education.ToString() + " " + groupNumber.ToString() + " " + MiddleMark.ToString();

        }

        // Полное копирование
        public override object DeepCopy()
        {
            Student a = new Student(base.DeepCopy() as Person, education, groupNumber);
            for (int i = 0; i < exams.Count; i++)
            {
                a.exams.Add(exams[i]);
            }
            for (int i = 0; i < tests.Count; i++)
            {
                a.tests.Add(tests[i]);
            }
            return a;
        }

        //Сортировка экзаменов студента по определенному ключу

        public void SortExam(string key)
        {
            switch (key)
            {
                case "name":
                    exams.Sort();
                    break;
                case "mark":
                    exams.Sort(new Exam());
                    break;
                case "date":
                    exams.Sort(new Exam.DateCompare());
                    break;
            }
        }
        #endregion

        #region Iterators
        // Итератор перебора объектов из списков exams и tests
        public IEnumerable<object> GetObjects()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                yield return exams[i];
            }
            for (int i = 0; i < tests.Count; i++)
            {
                yield return tests[i];
            }
        }

        // Итератор перебора всех экзаменов с оценкой большей заданной
        public IEnumerable<Exam> GetExams(int a)
        {
            for (int i = 0; i < exams.Count; i++)
            {
                if (exams[i].Mark > a)
                {
                    yield return exams[i];
                }
            }
        }

        // Итератор перебора сданных зачетов и экзаменов
        public IEnumerable<object> GetPassed()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                if (exams[i].Mark > 2)
                {
                    yield return exams[i];
                }
            }
            for (int i = 0; i < tests.Count; i++)
            {
                if (tests[i].isTestPassed)
                    yield return tests[i];
            }
        }

        // Итератор для перебора одинаковых сданных предметов
        public IEnumerable<Test> GetPassedTogether()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                for (int j = 0; j < tests.Count; j++)
                {
                    if (string.Compare(exams[i].SubjectName, tests[j].title) == 0 && tests[j].isTestPassed && exams[i].Mark > 2)
                    {
                        yield return tests[i];
                    }
                }
            }
        }

        // Итератор перебора названий всех предметов
        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                for (int j = 0; j < tests.Count; j++)
                {
                    if (string.Compare(exams[i].SubjectName, tests[j].title) == 0)
                    {
                        yield return exams[i].SubjectName;
                    }
                }
            }
        }
        #endregion
    }
}

