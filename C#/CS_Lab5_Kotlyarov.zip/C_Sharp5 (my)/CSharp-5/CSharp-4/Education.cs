﻿using System;
namespace CSharp__4
{
    enum Education
    {
        Specialist,
        Bachelor,
        SecondEducation
    }
}
