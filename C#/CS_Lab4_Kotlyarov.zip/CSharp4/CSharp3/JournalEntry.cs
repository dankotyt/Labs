﻿using CSharp_4;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    internal class JournalEntry
    {
        #region Properties
        public string NameCollection { get; set; }
        public Action ActionInfo { get; set; }
        public string SourceOfChange { get; set; }
        public string Key { get; set; }
        #endregion

        #region Constructor
        public JournalEntry(string name, Action action, string source, string key)
        {
            NameCollection = name;
            ActionInfo = action;
            SourceOfChange = source;
            Key = key;
        }
        #endregion

        #region Method
        public override string ToString()
        {
            return NameCollection + " " + ActionInfo.ToString() + " " + SourceOfChange + " " + Key.ToString() + " ";
        }
        #endregion
    }
}
