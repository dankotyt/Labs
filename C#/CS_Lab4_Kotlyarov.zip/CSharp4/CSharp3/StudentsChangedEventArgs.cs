﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    internal class StudentsChangedEventArgs<TKey> : EventArgs
    {
        #region Properties
        public string NameCollection { get; set; }
        public Action ActionInfo { get; set; }
        public string SourceOfChangeData { get; set; }
        public TKey Key { get; set; }
        #endregion

        #region Constructor
        public StudentsChangedEventArgs(string nameCollection, Action actionInfo, string sourceOfChange, TKey key)
        {
            NameCollection = nameCollection;
            ActionInfo = actionInfo;
            SourceOfChangeData = sourceOfChange;
            Key = key;
        }
        #endregion

        #region Method
        public override string ToString()
        {
            return NameCollection + " " + ActionInfo.ToString() + " " + SourceOfChangeData + " " + Key.ToString() + " ";
        }
        #endregion
    }
}
