﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using CSharp_4;

namespace CSharp_4  
{
    delegate TKey KeySelector<TKey>(Student st);
    delegate void StudentsChangedHandler<TKey>(object source, StudentsChangedEventArgs<TKey> args);
    internal class StudentCollection<TKey>
    {
        #region Fields and Events
        private Dictionary<TKey, Student> _dict;
        private KeySelector<TKey> _keySelector;
        public event StudentsChangedHandler<TKey> StudentChanged;
        #endregion

        #region Constructors
        public StudentCollection(KeySelector<TKey> keySelector)
        {
            _dict = new Dictionary<TKey, Student>();
            _keySelector = keySelector;
        }
        #endregion

        #region Methods
        public static string DefineKey(Student value)
        {
            return value.GroupNumber.ToString();
        }
        public void AddDefaults()
        {
            Student student = new Student(new Person("Random", "Name", new DateTime(2000, 10, 10)), Education.Specialist, 126);
            OnStudentChanged("StudentCollection", Action.Add, this.GetType().Name, _keySelector(student));
            _dict.Add(_keySelector(student), student);
        }

        public void AddStudents(params Student[] students)
        {
            for (int i = 0; i < students.Length; i++)
            {
                _dict.Add(_keySelector(students[i]), students[i]);
                OnStudentChanged("StudentCollection", Action.Add, this.GetType().Name, _keySelector(students[i]));
                students[i].PropertyChanged += HandleEvent;
            }
        }


        public override string ToString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString() + " ");
                OnStudentChanged("StudentCollection", Action.Property, this.GetType().Name, entry.Key);
                line.Append(entry.Value.ToString());
                line.Append("\n");
            }
            return line.ToString();
        }

        public string ToShortString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString());
                line.Append(entry.Value.ToShortString());
            }
            return line.ToString();
        }

        public bool Remove(Student st)
        {
            foreach (var item in _dict)
            {
                if (item.Value.Equals(st))
                {
                    OnStudentChanged("Student Collection", Action.Remove, this.GetType().Name, item.Key);
                    item.Value.PropertyChanged -= HandleEvent;
                    return _dict.Remove(item.Key);
                }
            }
            return false;
        }

        public void OnStudentChanged(string prop, Action action, string source, TKey key)
        {
            if (StudentChanged != null)
                StudentChanged(this, new StudentsChangedEventArgs<TKey>(prop, action, source, key));
        }

        public void HandleEvent(object subj, EventArgs eArgs) //обработка события
        {
            var a = (PropertyChangedEventArgs)eArgs;
            var b = (Student)subj;
            var key = _keySelector(b);
            OnStudentChanged("String Collection", Action.Property, a.PropertyName, key);
        }
        #endregion

        #region Properties
        public string NameCollection { get; set; }
        public double MaxAverageMark
        {
            get
            {
                List<double> averageMarks = new List<double>();
                foreach(var i in _dict)
                {
                    averageMarks.Add(i.Value.MiddleMark);
                }
                return Enumerable.Max(averageMarks);
            }
        }
        public IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> groupDict
        {
            get
            {
                IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> group = _dict.GroupBy(x => x.Value.Education);
                return group;
            }
        }

        #endregion

        #region Interfaces
        public IEnumerable<KeyValuePair<TKey, Student>> EducationForm(Education value)
        {
            
             IEnumerable<KeyValuePair<TKey, Student >> educDict= _dict.Where(x => x.Value.Education.Equals(value));
            return educDict;
        }
        #endregion
    }
}
