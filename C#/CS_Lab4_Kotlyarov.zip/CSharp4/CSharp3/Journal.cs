﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    internal class Journal
    {
        #region Fields
        //private List<JournalEntry> entries;
        List<JournalEntry> entries = new List<JournalEntry>();
        #endregion

        #region Events
        public void OnStudentsChanged(object source, EventArgs args)
        {
            var events = args as StudentsChangedEventArgs<string>;
            entries.Add(new JournalEntry(events.NameCollection, events.ActionInfo, events.SourceOfChangeData, events.Key));
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            string result = string.Empty;
            foreach (var element in entries)
            {
                result += "\nCollection was changed: " + element.NameCollection + " | Type of change: " + element.ActionInfo + " | Source of change data: " + element.SourceOfChange + " | Key: " + element.Key + "\n";
            }
            return result;
        }
        #endregion
    }
}
