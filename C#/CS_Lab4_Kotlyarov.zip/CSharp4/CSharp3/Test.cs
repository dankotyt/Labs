﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    internal class Test
    {
        public string title { get; set; }
        public bool isTestPassed { get; set; }

       public Test(string title, bool isTestPassed)
        {
            this.title = title;
            this.isTestPassed = isTestPassed;
        }

       public Test()
        {
            title = "";
            isTestPassed = false;
        }



        public override string ToString()
        {
            return title+" "+isTestPassed.ToString();
        }

    }
}
