﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    internal class Person : IDateAndCopy
    {
        protected string name;
        protected string surname;
        protected DateTime birthday;

        //Конструкторы 
        public Person()
        {
            name = "";
            surname = "";
            birthday = DateTime.MinValue;
        }
        public Person(string name, string surname, DateTime birthday)
        {
            this.name = name;
            this.surname = surname;
            this.birthday = birthday;
        }

        //Свойства
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public DateTime Date
        {
            get { return birthday; }
            set { birthday = value; }
        }

        public int BirhdayYear
        {
            get { return birthday.Year; }
            set { birthday = new DateTime(value, birthday.Month, birthday.Day); }
        }

        //Преобразование в строку
        public override string ToString()
        {
            return name + " " + surname + " " + birthday.ToShortDateString();

        }
        public virtual string ToShortString()
        {
            return name + " " + surname;
        }

        //Сравнение идентичности двух Person
        public override bool Equals(object obj)
        {
            return Equals(obj as Person);
        }

        public bool Equals(Person person)
        {
            if (ReferenceEquals(person, null))
            {
                return false;
            }
            if (ReferenceEquals(this, null))
            {
                return false;
            }
            return name.Equals(person.Name) && surname.Equals(person.surname) && birthday.Equals(person.birthday);
        }

        public static bool operator ==(Person a, Person b)
        {
           
            return a.Equals(b);
        }

        public static bool operator !=(Person a, Person b)
        {

            return a.Equals(b);
        }

        //Получение хэш-кода
        public override int GetHashCode()
        {

            return name.GetHashCode() + surname.GetHashCode() + birthday.GetHashCode();

        }

        //Полное копирование объекта
       public virtual object DeepCopy()
        {
            return new Person(name, surname, birthday);
        }
    }
}
