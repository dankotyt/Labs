﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_4
{
    
internal class Program
    {
        static void Main(string[] args)
        {
            StudentCollection<string> firstCollection = new StudentCollection<string>(StudentCollection<string>.DefineKey);
            StudentCollection<string> secondCollection = new StudentCollection<string>(StudentCollection<string>.DefineKey);

            Journal journal = new Journal();

            firstCollection.StudentChanged += journal.OnStudentsChanged;
            secondCollection.StudentChanged += journal.OnStudentsChanged;


            Person person1 = new Person("Random", "Surname", new DateTime(2004, 12, 12));
            Student student1 = new Student(person1, Education.Bachelor, 200);
            firstCollection.AddStudents(student1);

            Person person2 = new Person("Nerandom", "Nesurname", new DateTime(2003, 11, 11));
            Student student2 = new Student(person2, Education.SecondEducation, 251);
            secondCollection.AddStudents(student2);

            student1.Name = "Goodname";
            student2.Name = "Badname";
            student1.GroupNumber = 121;
            student2.GroupNumber = 287;

            firstCollection.Remove(student1);
            firstCollection.Remove(student2);

            secondCollection.Remove(student1);
            secondCollection.Remove(student2);

            student1.Name = "Karina";
            student2.Name = "Nastya";
            student1.GroupNumber = 188;
            student2.GroupNumber = 401;

            Console.WriteLine("Journal history:\n" + journal.ToString());

            Console.ReadKey();
        }
    }
}
