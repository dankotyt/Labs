﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace CSharp_2
{
    internal class Student : Person, IDateAndCopy, IEnumerable
    {
        private Education education;
        private int groupNumber;
        private List<Test> tests;
        private List<Exam> exams;

        // Конструкторы
        public Student(Person person, Education education, int groupNumber) :
            base(person.Name, person.Surname, person.Date)
        {

            this.education = education;
            this.groupNumber = groupNumber;
            tests = new List<Test>();
            exams = new List<Exam>();
        }

        public Student() :
            base()
        {
            education = new Education();
            groupNumber = 0;
            tests = new List<Test>();
            exams = new List<Exam>();
        }

        public Education Education { get { return education; } }
        // Свойство получения и изменения person из родительского класса
        public Person person
        {
            get
            {
                return base.DeepCopy() as Person;
            }
            set
            {
                name = base.name;
                surname = base.surname;
                birthday = base.birthday;
            }
        }

        // Счет средней оценки сданных предметов
        public double MiddleMark
        {
            get
            {
                int count = 0;
                double sum = 0;
                for (int i = 0; i < exams.Count; i++)
                {
                    count++;
                    sum += exams[i].Mark;

                }
                return sum / count;
            }
        }

        // Свойство экзаменов
        public List<Exam> Exams
        {
            get
            {
                return exams;
            }
            set
            {
                exams = value;
            }
        }

        //Добавление новых элементов в списки exams и tests
        public void AddExams(params Exam[] exams)
        {
            for (int i = 0; i < exams.Length; i++)
            {
                this.exams.Add(exams[i]);
            }
        }
        public void AddTest(Test test)
        {
            tests.Add(test);
        }

        //Индексатор для Education
        public bool this[Education education]
        {
            get
            {
                return this.education.Equals(education);
            }
        }

        // Итератор перебора объектов из списков exams и tests
        public IEnumerable<object> GetObjects()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                yield return exams[i];
            }
            for (int i = 0; i < tests.Count; i++)
            {
                yield return tests[i];
            }
        }

        // Итератор перебора всех экзаменов с оценкой большей заданной
        public IEnumerable<Exam> GetExams(int a)
        {
            for (int i = 0; i < exams.Count; i++)
            {
                if (exams[i].Mark > a)
                {
                    yield return exams[i];
                }
            }
        }

        // Преобразование в строку
        public override string ToString()
        {
            StringBuilder infoExams = new StringBuilder();
            for (int i = 0; i < exams.Count; i++)
            {
                infoExams.Append(exams[i].ToString() + " ");
            }
            for (int i = 0; i < tests.Count; i++)
            {
                infoExams.Append(tests[i].ToString() + " ");
            }
            return person.ToString() + " " + education.ToString() + " " + groupNumber.ToString() + " " + infoExams;
        }

        public virtual string ToShortString()
        {
            return person.ToString() + " " + education.ToString() + " " + groupNumber.ToString() + " " + MiddleMark.ToString();

        }

        // Полное копирование
        public override object DeepCopy()
        {
            Student a = new Student(base.DeepCopy() as Person, education, groupNumber);
            for (int i = 0; i < exams.Count; i++)
            {
                a.exams.Add(exams[i]);
            }
            for (int i = 0; i < tests.Count; i++)
            {
                a.tests.Add(tests[i]);
            }
            return a;
        }

        // Свойство получения и изменения номера группы
        public int GroupNumber
        {
            get { return groupNumber; }
            set
            {

                try
                {
                    if (value <= 100 || value > 599)
                    {
                        throw new Exception("Номер группы должен быть от 101 до 599");
                    }
                    else
                    {
                        groupNumber = value;
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
            }
        }
        // Итератор перебора названий всех предметов
        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                for (int j = 0; j < tests.Count; j++)
                {
                    if (string.Compare(exams[i].SubjectName, tests[j].title) == 0)
                    {
                        yield return exams[i].SubjectName;
                    }
                }
            }
        }

        // Итератор перебора сданных зачетов и экзаменов
        public IEnumerable<object> GetPassed()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                if (exams[i].Mark > 2)
                {
                    yield return exams[i];
                }
            }
            for (int i = 0; i < tests.Count; i++)
            {
                if (tests[i].isTestPassed)
                    yield return tests[i];
            }
        }

        // Итератор для перебора одинаковых сданных предметов
        public IEnumerable<Test> GetPassedTogether()
        {
            for (int i = 0; i < exams.Count; i++)
            {
                for (int j = 0; j < tests.Count; j++)
                {
                    if (string.Compare(exams[i].SubjectName, tests[j].title) == 0 && tests[j].isTestPassed && exams[i].Mark > 2)
                    {
                        yield return tests[i];
                    }
                }
            }
        }

        //Сортировка экзаменов студента по определенному ключу

        public void SortExam(string key)
        {
            switch (key)
            {
                case "name":
                    exams.Sort();
                    break;
                case "mark":
                    exams.Sort(new Exam());
                    break;
                case "date":
                    exams.Sort(new Exam.DateCompare());
                    break;
            }
        }
    }
}

