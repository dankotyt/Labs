﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_2
{
    
internal class Program
    {
        static void Main(string[] args)
        {
            /* 1. Создать объект Student и вызвать методы, выполняющие сортировку
               списка экзаменов List<Exam> по разным критериям, после каждой
               сортировки вывести данные объекта. Выполнить сортировку
               • по названию предмета;
               • по оценке;
               • по дате экзамена   
           */
            //Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Ex #1\n");

            // Инициализация полей Student
            Person person1 = new Person("AJora", "Fi", new DateTime(2006, 7, 4));
            Exam firstExam = new Exam("Russian", 4, new DateTime(2021, 8, 11));
            Exam secondExam = new Exam("History", 4, new DateTime(2021, 8, 20));
            Exam thirdExam = new Exam("IT", 5, new DateTime(2021, 9, 12));
            Test firstTest = new Test("IT", false);
            Test secondTest = new Test("Math", true);
            List<Exam> exams = new List<Exam>();
            List<Test> tests = new List<Test>();
            tests.Add(firstTest);
            tests.Add(secondTest);
            Student s1 = new Student(person1, Education.Bachelor, 121);
            s1.AddExams(firstExam);
            s1.AddExams(secondExam);
            s1.AddExams(thirdExam);

            Console.WriteLine("Студент #1: " + s1.ToString());
            s1.SortExam("name");
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Сортировка по названию: " + s1.ToString());
            s1.SortExam("mark");
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Сортировка по оценкам: " + s1.ToString());
            s1.SortExam("date");
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Сортировка по дате: " + s1.ToString());



            /* 2. Создать объект типа StudentCollection<string>. Добавить в коллекцию
               несколько разных элементов типа Student и вывести объект
               StudentCollection<string>  
           */
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Ex #2\n");

            // Инициилизирую новых студентов
            Person person2 = new Person("Random", "Name", new DateTime(1999, 2, 5));
            Exam e4 = new Exam("Math", 4, new DateTime(2023, 11, 18));
            Exam e5 = new Exam("Physics", 1, new DateTime(2023, 11, 20));
            Exam e6 = new Exam("IT", 5, new DateTime(2023, 11, 30));
            Test t3 = new Test("IT", true);
            Test t4 = new Test("Math", true);
            List<Exam> exam1 = new List<Exam>();
            List<Test> test1 = new List<Test>();
            test1.Add(firstTest);
            test1.Add(secondTest);
            Student s2 = new Student(person2, Education.Specialist, 226);
            s2.AddExams(e4);
            s2.AddExams(e5);
            s2.AddExams(e6);
            Console.WriteLine("Студент #2: " + s2.ToString());

            StudentCollection<string> studentCol = new StudentCollection<string>(StudentCollection<string>.DefineKey);
            studentCol.AddStudents(s1);
            studentCol.AddStudents(s2);
            Console.WriteLine("Коллекция студентов: " + "\n" + studentCol.ToString());

            /*  3. Вызвать методы класса StudentCollection<string>, выполняющие
                операции с коллекцией-словарем Dictionary<TKey, Student>, и после
                каждой операции вывести результат операции. Выполнить
                    • вычисление максимального значения среднего балла для
                    элементов коллекции; вывести максимальное значение;
                    • вызвать метод EducationForm для выбора студентов с заданной
                    формой обучения, вывести результат фильтрации;
                    • вызвать свойство класса, выполняющее группировку элементов
                    коллекции по форме обучения; вывести все группы элементов. 
            */
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Ex #3\n");

            Console.WriteLine("Максимальный средний балл: " + studentCol.MaxAverageMark);
            var resultPair = studentCol.EducationForm(Education.Bachelor);
            Console.WriteLine("Группировка по форме обучения: ");
            foreach (var pair in resultPair)
            {
                Console.WriteLine(pair.Value);
            }
            Console.WriteLine("Группировка: ");
            var result = studentCol.groupDict;
            foreach (var res in result)
            {
                Console.WriteLine(res.Key);
            }

            /* 4. Создать объект типа TestCollection<Person, Student>. Ввести число
               элементов в коллекциях и вызвать метод для поиска первого,
               центрального, последнего и элемента, не входящего в коллекции.
               Вывести значения времени поиска для всех четырех случаев. 
           */

            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("Ex #4\n");
            int number;
            Console.Write("Введите количество генерируемых элементов: ");
            number = Console.Read();
            TestCollections<Person, Student> finalValue = new TestCollections<Person, Student>(number, TestCollections<Person, Student>.GenerateElement);
            finalValue.searchListOfTKeys();
            finalValue.searchListOfString();
            finalValue.searchKeyInDictOfTKeys();
            finalValue.searchKeyInDictOfString();
            finalValue.searchValueInDictOfTKeys();
            finalValue.searchValueInDictOfString();
            Console.ReadKey();



        }
    }
}
