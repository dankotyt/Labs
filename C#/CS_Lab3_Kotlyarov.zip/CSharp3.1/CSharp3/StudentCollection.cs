﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace CSharp_2
{
    delegate TKey KeySelector<TKey>(Student st);

    internal class StudentCollection<TKey>
    {
        private Dictionary<TKey, Student> _dict;
        private KeySelector<TKey> _keySelector;

       public StudentCollection(KeySelector<TKey> keySelector)
        {
            _dict = new Dictionary<TKey, Student>();
            _keySelector = keySelector;
        }
        public static string DefineKey(Student val)
        {
            return val.GroupNumber.ToString();
        }
        public void AddDefaults()
        {
            Student student = new Student(new Person("Random", "Name", new DateTime(2000, 10, 10)), Education.Specialist, 126);
            _dict.Add(_keySelector(student), student);
        }

        public void AddStudents(params Student[] students)
        {
            for (int i = 0; i < students.Length; i++)
            {
                
                _dict.Add(_keySelector(students[i]), students[i]);
            }
        }


        public override string ToString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString()+" ");
                line.Append(entry.Value.ToString());
                line.Append("\n");
            }
            return line.ToString();
        }

        public string ToShortString()
        {
            StringBuilder line = new StringBuilder();
            foreach (KeyValuePair<TKey, Student> entry in _dict)
            {
                line.Append(entry.Key.ToString());
                line.Append(entry.Value.ToShortString());
            }
            return line.ToString();
        }


        public double MaxAverageMark
        {
            get
            {
                List<double> averageMarks = new List<double>();
                foreach(var i in _dict)
                {
                    averageMarks.Add(i.Value.MiddleMark);
                }
                return Enumerable.Max(averageMarks);
            }
        }


       public  IEnumerable<KeyValuePair<TKey, Student>> EducationForm(Education value)
        {
            
             IEnumerable<KeyValuePair<TKey, Student >> educDict= _dict.Where(x => x.Value.Education.Equals(value));
            return educDict;
        }

       public IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> groupDict
        {
            get
            {
                IEnumerable<IGrouping<Education, KeyValuePair<TKey, Student>>> group = _dict.GroupBy(x=>x.Value.Education);
                return group;

            }
        }


    }
}
