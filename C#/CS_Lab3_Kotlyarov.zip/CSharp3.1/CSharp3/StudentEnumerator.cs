﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_2
{
    internal class StudentEnumerator : IEnumerator
    {
     
        Student[] student;
        int index = -1;
        public bool MoveNext()
        {
            if (index == student.Length - 1)
            {
                Reset();
                return false;
            }

            index++;
            return true;
        }

        public void Reset()
        {
            index = -1;
        }
        public object Current
        {
            get
            {
                return student[index];
            }
        }

    }
  

}

