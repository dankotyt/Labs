﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_2
{
    internal class Exam:IDateAndCopy,IComparable,IComparer<Exam>
    {
        // Свойства
        public string SubjectName { get; set; }
        public int Mark { get; set; }
        public DateTime Date { get; set; }

        // Конструкторы
        public Exam(string subjectName, int mark, DateTime date)
        {
            SubjectName = subjectName;
            this.Mark = mark;
            this.Date = date;
        }
        public Exam()
        {
            SubjectName = "";
            Mark = 0;
            Date = DateTime.MinValue;
        }

        public override string ToString()
        {
            return SubjectName + " " + Mark.ToString() + " " + Date.ToShortDateString();
        }

        
        public object DeepCopy()
        {
            return new Exam(SubjectName, Mark, Date);
        }

        public  int CompareTo(object exam)
        {
            return SubjectName.CompareTo((exam as Exam).SubjectName);
        }

       
       public  int Compare(Exam exam1, Exam exam2)
        {
           return exam1.Mark - exam2.Mark;
        
        }

        public class DateCompare : IComparer<Exam>
        {
            public int Compare(Exam exam1, Exam exam2)
            {
                return exam1.Date.CompareTo(exam2.Date);
            }

        }



    }
}
