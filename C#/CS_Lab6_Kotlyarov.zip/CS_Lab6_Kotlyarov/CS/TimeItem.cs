﻿using System;
using System.Text;

namespace CSharp
{
    [Serializable]
    public class TimeItem
    {
        public int size;
        public int repetitionsNumber;
        public long CSTime;
        public double CPPTime;
        public double coefficient;


        public TimeItem(int size, int repetitionsCount, long CSTime, double CPPTime)
        {
            this.size = size;
            repetitionsNumber = repetitionsCount;
            this.CSTime = CSTime;
            this.CPPTime = CPPTime;
            coefficient = CSTime / CPPTime;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append($"Размер матрицы: {size}\n");
            sb.Append($"Число повторений: {repetitionsNumber}\n");
            sb.Append($"Время исполнения С# кода: {CSTime}\n");
            sb.Append($"Время исполнения C++ кода: {CPPTime}\n");
            sb.Append($"Во сколько раз исполнение С# кода медленее исполнения С++ кода: {coefficient}\n\n");

            return sb.ToString();
        }
    }
}