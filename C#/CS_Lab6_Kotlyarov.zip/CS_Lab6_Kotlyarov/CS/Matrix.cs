﻿using System;
using System.Text;

namespace CSharp
{
    public class Matrix
    {
        public int Size { get; }
        public double[] Row;

        public Matrix(int n)
        {
            var rnd = new Random();
            Size = n;
            Row = new double[Size];
            for (int i = 0; i < Size; i++)
            {
                Row[i] = rnd.NextDouble() * 10 + 1;
            }
        }

        public Matrix()
        {
            var rnd = new Random();
            Console.Write("Введите размер матрицы: ");
            Size = Convert.ToInt32(Console.ReadLine());
            Row = new double[Size];
            for ( int i = 0; i < Size; i++)
            {
                Console.Write($"{i} элемент: ");
                Row[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public Matrix(int size, double[] source)
        {
            Size = size;
            Row = new double[Size];
            for (int i = 0; i < Size; i++)
            {
                Row[i] = source[i];
            }
        }

        /*
         b - left part
         x - array for answers
         */
        public void Solve(double[] b, double[] x)
        {
            int m = Size;
            var a1 = new double[m];
            var b1 = new double[m];

            int j, k, kj;
            double rk, sk, fkk;

            a1[0] = 1 / Row[0];
            x[0] = b[0] * a1[0];
            b1[0] = 0;
            for (k = 2; k <= m; ++k)
            {
                a1[k - 1] = 0;
                x[k - 1] = 0;
                rk = 0;
                fkk = 0;
                for (j = 2; j <= k; ++j)
                {
                    kj = k - j + 1;
                    b1[j - 1] = a1[kj - 1];
                    rk += Row[j - 1] * b1[j - 1];
                    fkk += Row[j - 1] * x[kj - 1];
                }
                fkk = b[k - 1] - fkk;
                sk = 1 / (1 - rk * rk);
                rk = -rk * sk;
                for (j = 1; j <= k; ++j)
                {
                    kj = k - j + 1;
                    a1[j - 1] = a1[j - 1] * sk + b1[j - 1] * rk;
                    x[kj - 1] += a1[j - 1] * fkk;
                }
            }

        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    sb.Append($"{GetElement(i, j):f4}");
                }
            }

            return sb.ToString();
        }

        private double GetElement(int i, int j)
        {
            return Row[Math.Abs(i - j)];
        }
    }
}