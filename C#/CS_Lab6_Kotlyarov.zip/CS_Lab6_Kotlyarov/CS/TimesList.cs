﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace CSharp
{
    public class TimesList
    {
        private List<TimeItem> items = new List<TimeItem>();

        public void Add(TimeItem item)
        {
            items.Add(item);
        }

        public void Save(string filename)
        {
            try
            {
                var formatter = new BinaryFormatter();
                var fs = new FileStream(filename, FileMode.OpenOrCreate);
                formatter.Serialize(fs, items);
                fs.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Ошибка");
                Console.WriteLine(e.Message);
            }
        }

        public void Load(string filename)
        {
            try
            {
                var formatter = new BinaryFormatter();
                var fs = new FileStream(filename, FileMode.OpenOrCreate);
                items = formatter.Deserialize(fs) as List<TimeItem>;
                fs.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Ошибка");
                Console.WriteLine(e.Message);
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var item in items)
            {
                sb.Append(item);
            }
            return sb.ToString();
        }
    }
}