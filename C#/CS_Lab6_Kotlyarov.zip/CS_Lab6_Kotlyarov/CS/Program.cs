﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace CSharp
{
    class Program
    {
        [DllImport(@"CPP.dll")]
        public static extern double SolveRepeatCPP(int matrixOrder, int repetitionCount);

        [DllImport(@"CPP.dll")]
        public static extern void SolveMatrixCPP(int matrixOrder, double[] sourceMatrix, double[] right, double[] ans);


        static void Main(string[] args)
        {

            #region Test

            var rightTest = new double[3] { 60, 30, 60 };
            var testMatrix = new double[] { 1, 2, 3 };
            var x = new double[3] { 0, 0, 0 };

            var test = new Matrix(3, testMatrix);
            test.Solve(rightTest, x);
            Console.WriteLine("Решение системы через C#:\n");
            foreach (var i in x)
            {
                Console.WriteLine($"{i:f4}");
            }

            // C++ test
            SolveMatrixCPP(3, testMatrix, rightTest, x);
            Console.WriteLine("\nРешение системы через C++:\n");
            foreach (var i in x)
            {
                Console.WriteLine($"{i:f4}");
            }

            #endregion

            var times = new TimesList();
            Console.WriteLine("\n\nВведите название файла: ");
            string filename;
            do
            {
                filename = Console.ReadLine();
            } while (filename.Length == 0);

            try
            {
                var fileInfo = new FileInfo(filename);
                if (fileInfo.Exists)
                {
                    times.Load(filename);
                    Console.WriteLine(times);
                }
                else
                {
                    Console.WriteLine("\nДанного файла не существует, поэтому он будет создан");
                    fileInfo.Create().Close();
                }

                var command = "1";
                while (command == "1")
                {
                    Console.WriteLine("\nВведите 1, если хотите установить новый размер матрицы и новое число повторений. " +
                        "Любое другое значение - запустит сравнение решений.");
                    command = Console.ReadLine();
                    if (command != "1") break;

                    Console.Write("\nВведите размер матрицы: ");
                    var size = Convert.ToInt32(Console.ReadLine());
                    Console.Write("\nВведите число повторений: ");
                    var repetitionsNumber = Convert.ToInt32(Console.ReadLine());

                    var CSTime = Solver.SolveRepeatCS(size, repetitionsNumber);

                    var CPPTime = SolveRepeatCPP(size, repetitionsNumber);

                    times.Add(new TimeItem(size, repetitionsNumber, CSTime, CPPTime));

                }

                Console.WriteLine("\nВсе временные измерения: ");
                Console.WriteLine(times);
                times.Save(filename);
                Console.WriteLine("Нажмите любую кнопку для закрытия программы.");
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}