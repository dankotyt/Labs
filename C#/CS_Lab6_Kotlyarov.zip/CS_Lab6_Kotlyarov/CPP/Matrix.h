#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <cstdlib>
#include <iostream>


class Matrix {
private:
	int size;
	double* row;
public:
	Matrix(int);
	Matrix();
	Matrix(int, double*);
	Matrix(const Matrix&);
	~Matrix();
	Matrix& operator=(const Matrix&);
	void Solve(double*, double*);
};
