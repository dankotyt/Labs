#include "Matrix.h"

Matrix::Matrix(int n) {
    size = n;
    row = new double[size];
    for (int i = 0; i < size; i++) {
        row[i] = static_cast<double>(rand()) / RAND_MAX * 10 + 1;
    }
}

Matrix::Matrix() {
    printf("������� ������ �������: ");
    std::cin >> size;
    row = new double[size];
    for (int i = 0; i < size; i++) {
        std::cout << i << " �������: ";
        std::cin >> row[i];
    }
}

Matrix::Matrix(int size, double* source) {
    this.size = size;
    row = new double[size];
    for (int i = 0; i < size; i++) {
        row[i] = source[i];
    }
}

Matrix::Matrix(const Matrix& source) {
    size = source.size;
    row = new double[size];
    for (int i = 0; i < size; i++) {
        row[i] = source.row[i];
    }
}

Matrix::~Matrix() {
    delete[] row;
}

Matrix& Matrix::operator=(const Matrix& source) {
    if (row != source.row) {
        delete[] row;
        size = source.size;
        row = new double[size];
        for (int i = 0; i < size; i++) {
            row[i] = source.row[i];
        }
    }
    return *this;
}


void Matrix::Solve(double* b, double* x) {
    double* a = row;
    int m = size;


    double* a1 = new double[m];
    double* b1 = new double[m];


    int j, k, kj;
    double rk, sk, fkk;

    a1[0] = 1. / a[0];
    x[0] = b[0] * a1[0];
    b1[0] = 0.;
    for (k = 2; k <= m; ++k) {
        a1[k - 1] = 0.;
        x[k - 1] = 0.;
        rk = 0.;
        fkk = 0.;
        for (j = 2; j <= k; ++j) {
            kj = k - j + 1;
            b1[j - 1] = a1[kj - 1];
            rk += a[j - 1] * b1[j - 1];
            fkk += a[j - 1] * x[kj - 1];
        }
        fkk = b[k - 1] - fkk;
        sk = 1. / (1. - rk * rk);
        rk = -rk * sk;
        for (j = 1; j <= k; ++j) {
            kj = k - j + 1;
            a1[j - 1] = a1[j - 1] * sk + b1[j - 1] * rk;
            x[kj - 1] += a1[j - 1] * fkk;
        }
    }

    delete[] a1;
    delete[] b1;
}