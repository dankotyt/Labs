﻿#include <string>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <cstring>
#include <algorithm>
#include <locale>

using namespace std;

bool isFioCorrect(string& line);
bool isNumberCorrect(string& line);
bool isStringCorrect(string& line);
bool isDepartCorrect(string& line);

class Man
{
protected:
	string name;
	string surname;
public:
	Man(const string& name, const string& surname) : name(name), surname(surname) {}
	string getName() const {
		return name;
	}
	string getSurname() const {
		return surname;
	}
	void setName(const string& name) {
		this->name = name;
	}
	void setSurname(const string& surname) {
		this->surname = surname;
	}
	Man() {}
};

class Common {
public:


	Man getFullName() const {
		return fname;
	}

	void setFullName(string name, string surname) {
		fname = (Man(name, surname));
	}

	Common() {};

	Common(const string& name, const string& surname) {
		fname.setName(name);
		fname.setSurname(surname);
	}

protected:
	Man fname;
};
class leaner : public Common {
private:
	int group;

public:
	leaner() :Common() {
		group = 0;
	}
	leaner(const string& name, const string& surname, int numGroup) : Common(name, surname) {
		group = numGroup;
	}

	int getGroup() const {
		return group;
	}

	void setGroup(int _group) {
		group = _group;
	}

	friend ostream& operator<<(ostream& out, const leaner& student) {
		return out << student.getFullName().getName() << " " << student.fname.getSurname() << " " << student.getGroup() << endl;
	}

	friend istream& operator>>(istream& is, leaner& student) {
		string sur;
		string name;
		string grp;
		int group;
		while (true)
		{
			cout << "Введите имя студента: " << endl;
			is >> name;
			bool p = isFioCorrect(name);
			if (!p)
			{
				continue;
			}
			break;
		}
		while (true)
		{
			cout << "Введите фамилию студента: " << endl;
			is >> sur;
			bool p = isFioCorrect(sur);
			if (!p)
			{
				continue;
			}
			break;
		}
		student.fname.setName(name);
		student.fname.setSurname(sur);
		while (true)
		{
			cout << "Введите номер группы (от 1 до 200): " << endl;
			is >> grp;
			if (isNumberCorrect(grp)) 
			{
				istringstream iss(grp); //преобразуем в int
				iss >> group;
			}
			student.setGroup(group);
			return is;
			break;
		}
	}
	bool operator==(const Man& other) {
		return (fname.getName() == other.getName() && fname.getSurname() == other.getSurname());
	}
};

enum Department { SPINTEX, BMS, PKIMS };

class prepod : public Common
{
private:
	string course;
	Department  department;
public:
	prepod() {
		course = " ";
		Department department;
	}
	prepod(const string& name, const string& surname, string& course, Department department) : Common(name, surname) {
		this->course = course;
		this->department = department;
	}

	string getCourse() {
		return course;
	}
	Department getDepartment() {
		return department;
	}
	void setCourse(string course) {
		this->course = course;
	}
	void setDepartment(Department department) {
		this->department = department;
	}
	bool operator==(Man& other) {
		return(fname.getName() == other.getName() && fname.getSurname() == other.getSurname());
	}
	friend ostream& operator<<(ostream& out, const prepod& teacher) {
		return out << teacher.fname.getName() << " " << teacher.fname.getSurname() << " " << teacher.course << " " << teacher.department + 1 << endl;
	}
	friend istream& operator>>(istream& is, prepod& teacher) {
		string s;
		string sur;
		string name;
		int dep;
		
		while (true)
		{
			cout << "\nВведите имя преподавателя: " << endl;
			is >> name;
			bool p = isFioCorrect(name);
			if (!p)
			{
				continue;
			}
			break;
		}
		while (true)
		{
			cout << "\nВведите фамилию преподавателя: " << endl;
			is >> sur;
			bool p = isFioCorrect(sur);
			if (!p)
			{
				continue;
			}
			break;
		}
		teacher.fname.setName(name);
		teacher.fname.setSurname(sur);
		while (true)
		{
			cout << "\nВведите читаемый курс: " << endl;
			is >> teacher.course;
			bool p = isStringCorrect(teacher.course);
			if (!p)
			{
				continue;
			}
			break;
		}
		while (true)
		{
			cout << "\nВведите номер кафедры (1 - СПИНТех, 2 - БМС, 3 - ПКИМС): " << endl;
			is >> s;

			if (isDepartCorrect(s) and isNumberCorrect(s))
			{
				istringstream iss(s); //преобразуем в int
				iss >> s;
				if (s == "1") {
					teacher.setDepartment(Department::SPINTEX);
				}
				else if (s == "2") {
					teacher.setDepartment(Department::BMS);
				}
				else if (s == "3") {
					teacher.setDepartment(Department::PKIMS);
				}
				break;
				}
			}
		return is;
	}
};

void searchLeaner(const string& name, const string& surname, vector<leaner>& leaners) {
	cout << "Найденные студенты: " << endl;
	bool found = false;
	for (const leaner student : leaners)
	{
		if (student.getFullName().getName() == name && student.getFullName().getSurname() == surname) {
			cout << student << endl;
			found = true;
		}
	}
	if (found != true)
	{
		cout << "\nСтудентов с заданным именем и фамилией нет!\n";
	}
};
void searchPrepod(const string& name, const string& surname, vector<prepod>& prepods) {
	cout << "Найденные преподаватели: " << endl;
	bool found = false;
	for (const prepod teacher : prepods)
	{
		if (teacher.getFullName().getName() == name && teacher.getFullName().getSurname() == surname) {
			cout << teacher << endl;
			found = true;
		}
	}
	if (found != true)
	{
		cout << "\nПреподавателей с заданным именем и фамилией нет!\n";
	}
};

void addLeaner(string name, string surname, int groupNumber, vector<leaner>& leaners) {
	leaner student;
	student.setFullName(name, surname);
	student.setGroup(groupNumber);
	leaners.push_back(student);
}

void addPrepod(string name, string surname, string course, Department depart, vector<prepod>& prepods) {
	prepod teacher;
	teacher.setFullName(name, surname);
	teacher.setCourse(course);
	teacher.setDepartment(depart);
	prepods.push_back(teacher);
}

//bool isFileEmpty(const string& filename) {
//	ifstream file(filename);
//	return file.peek() == ifstream::traits_type::eof();
//}

bool isFioCorrect( string& line) {
	try
	{
		for (char i : line)
		{
			if (!isalpha(i) && !isalpha(i, locale("ru_RU")))
			{
				throw string{ "\nВ имени/фамилии не может быть посторонних символов!\n" };
			}
		}
		if (line.size() <= 0 || line.size() >= 15)
		{
			throw string{ "\nНе должно быть более 15 символов!\n" };
		}
		return true;
	}
	catch (string error)
	{
		cout << error << endl;
		return false;
	}
	return true;
}

bool isStringCorrect(string& line) {
	try
	{
		for (char i : line)
		{
			if (!isalpha(i) && !isalpha(i, locale("ru_RU")))
			{
				throw string{ "\nПосторонних символов тут быть не может!" };
			}
		}
		if (line.size() <= 0 || line.size() >= 15)
		{
			throw string{ "\nНе должно быть более 15!" };
		}
		return true;
	}
	catch (string error)
	{
		cout << error << endl;
		return false;
	}
	return true;
}

bool isNumberCorrect(string& line) {
	int s;
	try
	{
		for (char i : line)
		{
			if (!isdigit(i))
			{
				throw string{ "\nВ числовом формате не может быть букв и посторонних символов!" };
			}
		}
		istringstream iss(line); //преобразуем в int
		iss >> s;
		if (s <= 0 or s >= 200)
		{
			throw string{ "\nГруппа не может быть меньше 0 или больше 200." };
		}
		return true;
	}
	catch (string error)
	{
		cout << error << endl;
		return false;
	}
}

bool isDepartCorrect(string& line) {
	try
	{
		for (char i : line)
		{
			if (i <= '0' || i >= '4')
			{
				throw string{ "\nОшибка ввода номера института!\n" };
			}
		}
		return true;
	}
	catch (string error)
	{
		cout << error << endl;
		return false;
	}
}

void menu() {
	cout << "==================== Главное меню ====================" << endl;
	cout << "1. Вывести информацию обо всех студентах/преподавателях " << endl;
	cout << "2. Поиск студента/преподавателя по имени и фамилии " << endl;
	cout << "3. Добавить студента/преподавателя " << endl;
	cout << "4. Выход " << endl;
	cout << "\n\nВаш выбор: ";
}
int main() {
	setlocale(LC_ALL, "Russian");
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	int choice;
	string line;
	string s;
	string n;
	int num;
	int numb;
	string cour;
	Department dep = SPINTEX;
	string choice2;
	string choice3;
	bool quit = true;
	fstream file;
	file.open("text.txt", ios::in | ios::out | ios::app);
	// читаем количества элементов в двух массивах
	int number = 0;
	int number2 = 0;
	getline(file, s, ' ');
	getline(file, n, '\n');
	if (!s.empty()) {
		number = stoi(s);
		number2 = stoi(n);
	}

	vector<leaner> leaners;
	vector<prepod> prepods;
	leaner l;
	prepod p;
	if (number == 0) {
		cout << "Добро пожаловать в базу данных. Введите первого пользователя." << endl;
		leaners.push_back(l);
		cin >> leaners.at(0);
		cout << "\nОтлично! Теперь добавим преподавателя." << endl;
 		prepods.push_back(p);
		cin >> prepods.at(0);
	}
	else {
		int i = 0;
		while (i != number)
		{
			leaners.push_back(l);
			getline(file, s, ' ');

			getline(file, n, ' ');
			leaners.at(i).setFullName(s, n);

			getline(file, s, '\n');
			leaners.at(i).setGroup(stoi(s));
			i++;
		}
		i = 0;
		while (i != number2) {
			prepods.push_back(p);
			getline(file, s, ' ');

			getline(file, n, ' ');
			prepods.at(i).setFullName(s, n);

			getline(file, s, ' ');
			prepods.at(i).setCourse(s);

			getline(file, s, '\n');
			if (s == "SPINTEX") {
				prepods.at(i).setDepartment(Department::SPINTEX);
			}
			else if (s == "BMS") {
				prepods.at(i).setDepartment(Department::BMS);
			}
			else {
				prepods.at(i).setDepartment(Department::PKIMS);
			}
			i++;
		}
	}
	menu();
	cin >> choice;
	file.open("info.txt", ios::in | ios::out | ios::app);
	while (quit)
	{
		switch (choice)
		{
		case 1:

			cout << "\nИнформация о студентах: " << endl;
			for (int i = 0; i < leaners.size(); i++)
			{
				cout << leaners[i];
			}
			cout << "Информация о преподавателях: " << endl;
			for (int i = 0; i < prepods.size(); i++)
			{
				cout << prepods[i];
			}
			choice = 0;
			break;
		case 2:
			cout << "\nКого будем искать? (напишите 'student', если хотите добавить студента, или 'prepod', если хотите добавить преподавателя)" << endl;
			/*cout << "\nВаш выбор: ";
			cin >> choice2;*/

			while (true)
			{
				cout << "\nВаш выбор: ";
				cin >> choice2;
				bool p = isStringCorrect(choice2);
				if (!p)
				{
					cout << "\nНеверный ввод!" << endl;
					continue;
				}
				break;
			}

			//transform(choice2.begin(), choice2.end(), choice2.begin(), tolower);
			if (choice2 == "prepod") {
				cout << "\nВведите имя: ";
				cin >> n;
				cout << "\nВведите фамилию: ";
				cin >> s;
				cout << "\n\n";
				searchPrepod(n, s, prepods);
			}
			else if (choice2 == "student") {
				cout << "\nВведите имя: ";
				cin >> s;
				cout << "\nВведите фамилию: ";
				cin >> n;
				cout << "\n\n";
				searchLeaner(s, n, leaners);
			}
			else {
				cout << "\nНеверный ввод! Попробуйте ещё раз!";
			}
			choice = 0;
			break;
		case 3:
			file.open("info.txt", ios::in | ios::out | ios::app);
			cout << "Кого вы хотите добавить? (напишите 'student', если хотите добавить студента, или 'prepod', если хотите добавить преподавателя)\n";
			cout << "\nВаш выбор: ";
			cin >> choice3;
			//transform(choice3.begin(), choice3.end(), choice3.begin(), tolower);

			if (choice3 == "student") {
				/*cout << "\nВведите имя студента: " << endl;
				cin >> n;*/
				cout << "\nВведите имя студента: " << endl;
				cin >> n;
				if (!isFioCorrect(n))
				{
					throw string{ "\nИмя некорректно!\n" };
				}
				
				cout << "\nВведите фамилию студента: " << endl;
				cin >> s;
				if (!isFioCorrect(s))
				{
					throw string{ "\nФамилия некорректна!\n" };
				}
				cout << "\nВведите номер группы: " << endl;
				cin >> line; 
				if (!isNumberCorrect(line))
				{
					throw string{ "\nНомер группы некорректный!\n" };
				}
				istringstream iss(line); //преобразуем в int
				iss >> num;
				if (file.is_open())
				{
					cout << "Данные успешно записаны!" << endl;
					addLeaner(n, s, num, leaners);
				}
				else {
					cout << "Записать информацию в файл не удалось!" << endl;
				}
			}
			else if (choice3 == "prepod") {
				int d;
				cout << "\nВведите имя преподавателя: " << endl;
				cin >> n;
				if (!isFioCorrect(n))
				{
					throw string{ "\nИмя некорректно!\n" };
				}
				cout << "\nВведите фамилию преподавателя: " << endl;
				cin >> s;
				if (!isFioCorrect(s))
				{
					throw string{ "\nФамилия некорректна!\n" };
				}
				cout << "\nВведите читаемый курс: " << endl;
				cin >> cour;
				if (!isStringCorrect(cour))
				{
					throw string{ "\nДисциплина введена неверно!\n" };
				}
				cout << "\nВведите номер института, за которым прикреплен преподаватель (1 - СПИНТех, 2 - БМС, 3 - ПКИМС): " << endl;
				while (true) {
					cin >> d;
					if (d == 1) {
						dep = Department::SPINTEX;
						break;
					}
					else if (d == 2) {
						dep = Department::BMS;
						break;
					}
					else if (d == 3) {
						dep = Department::PKIMS;
						break;
					}
					else {
						cout << "Неправильный ввод!" << endl;
					}
				}
				cout << "Данные успешно записаны!" << endl;
				addPrepod(n, s, cour, dep, prepods);
			}
			else {
				cout << "\n\nНеверный выбор!" << endl;
			}
			choice = 0;
			break;
		case 4:
			cout << "Выход из программы" << endl;
			file.close();
			file.open("text.txt", ios::out | ios::trunc);
			file << leaners.size() << " " << prepods.size() << "\n";
			for (int i = 0; i < leaners.size(); i++) {
				file << leaners[i].getFullName().getName() << " " << leaners[i].getFullName().getSurname() << " " << leaners[i].getGroup() << endl;
			}
			for (int i = 0; i < prepods.size(); i++) {
				file << prepods[i].getFullName().getName() << " " << prepods[i].getFullName().getSurname() << " " << prepods[i].getCourse() << " " << prepods[i].getDepartment() << endl;
			}
			file.close();
			quit = false();
			break;
		case 0:
			cout << "\n\n";
			menu();
			cin >> choice;
			break;
		default:
			cout << "Такого варианта выбора нет!";
			choice = 0;
			break;
		}
	}
	system("pause");
}
